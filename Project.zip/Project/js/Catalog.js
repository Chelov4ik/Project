const template = document.getElementById('car-template');
const carTemplate = template.content.querySelector('.car');
var targetDiv = document.getElementById('targetDiv');

getData().forEach(car => {
  const carElem = document.importNode(carTemplate, true);
  for (const key in car) {
    if (key === 'img') {
      carElem.querySelector('.img').src = car.img;
    } else {
      carElem.querySelector('.' + key).textContent = car[key];
    }
  }
  targetDiv.appendChild(carElem);
});

document.getElementById("getValueButton").addEventListener("click", function() {
  var modelComboBox = document.getElementById("carComboBox");
  var colorComboBox = document.getElementById("carColorComboBox");
  var bodyComboBox = document.getElementById("carBodyComboBox");
  var minYearInput = document.getElementById("minYear");
  var maxYearInput = document.getElementById("maxYear");

  var selectedModel = modelComboBox.value;
  var selectedColor = colorComboBox.value;
  var selectedBody = bodyComboBox.value;
  var minYear = minYearInput.value ? parseInt(minYearInput.value) : null;
  var maxYear = maxYearInput.value ? parseInt(maxYearInput.value) : null;

  updateTargetDiv(selectedModel, selectedColor, selectedBody, minYear, maxYear);
});

function updateTargetDiv(selectedModel, selectedColor, selectedBody, minYear, maxYear) {
  // Очистка целевого контейнера перед добавлением новых элементов
  targetDiv.innerHTML = '';

  // Логгирование для отладки
  console.log(`Selected Model: ${selectedModel}`);
  console.log(`Selected Color: ${selectedColor}`);
  console.log(`Selected Body: ${selectedBody}`);
  console.log(`Min Year: ${minYear}`);
  console.log(`Max Year: ${maxYear}`);

  // Перебор данных и создание новых элементов
  getData().forEach(car => {
    if ((selectedModel == "All" || car.model === selectedModel) &&
        (selectedColor == "All" || car.color === selectedColor) &&
        (selectedBody == "All" || car.body === selectedBody) &&
        (minYear === null || car.year >= minYear) &&
        (maxYear === null || car.year <= maxYear)) {
      const carElem = carTemplate.cloneNode(true);
      carElem.querySelector('.img').src = car.img;
      carElem.querySelector('.model').textContent = car.model;
      carElem.querySelector('.year').textContent = car.year;
      carElem.querySelector('.color').textContent = car.color;
      carElem.querySelector('.body').textContent = car.body;
      targetDiv.appendChild(carElem);
    }
  });
}
function getData() {
  return [
      {
          "model": "BMW",
          "year": 1967,
          "color": "Red",
          "body": "Sedan",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "BMW",
          "year": 1975,
          "color": "Blue",
          "body": "Convertible",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "Mercedes",
          "year": 1980,
          "color": "White",
          "body": "SUV",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "Mercedes",
          "year": 1995,
          "color": "Black",
          "body": "Hard top",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "Toyota",
          "year": 2005,
          "color": "Yellow",
          "body": "Sedan",
          "img": "../assets/img/download (1).jpeg"
      },
      {
          "model": "Toyota",
          "year": 2010,
          "color": "Red",
          "body": "SUV",
          "img": "../assets/img/download (1).jpeg"
      },
      {
          "model": "Ford",
          "year": 2015,
          "color": "Blue",
          "body": "Convertible",
          "img": "../assets/img/download (3).jpeg"
      },
      {
          "model": "Ford",
          "year": 2020,
          "color": "White",
          "body": "Sedan",
          "img": "../assets/img/download (3).jpeg"
      },
      {
          "model": "Chevrolet",
          "year": 1965,
          "color": "Black",
          "body": "Hard top",
          "img": "../assets/img/download (4).jpeg"
      },
      {
          "model": "Chevrolet",
          "year": 1970,
          "color": "Yellow",
          "body": "SUV",
          "img": "../assets/img/download (4).jpeg"
      },
      {
          "model": "Honda",
          "year": 2000,
          "color": "Green",
          "body": "Sedan",
          "img": "../assets/img/download (1).jpeg"
      },
      {
          "model": "Honda",
          "year": 2007,
          "color": "Black",
          "body": "Convertible",
          "img": "../assets/img/download (1).jpeg"
      },
      {
          "model": "Nissan",
          "year": 2012,
          "color": "Blue",
          "body": "SUV",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "Nissan",
          "year": 2018,
          "color": "Red",
          "body": "Hard top",
          "img": "../assets/img/download (2).jpeg"
      },
      {
          "model": "Audi",
          "year": 1998,
          "color": "Yellow",
          "body": "Sedan",
          "img": "../assets/img/download (3).jpeg"
      },
      {
          "model": "Audi",
          "year": 2002,
          "color": "White",
          "body": "Convertible",
          "img": "../assets/img/download (3).jpeg"
      },
      {
          "model": "Volkswagen",
          "year": 2006,
          "color": "Red",
          "body": "SUV",
          "img": "../assets/img/download (4).jpeg"
      },
      {
          "model": "Volkswagen",
          "year": 2015,
          "color": "Black",
          "body": "Hard top",
          "img": "../assets/img/download (4).jpeg"
      },
      {
          "model": "Hyundai",
          "year": 2010,
          "color": "Blue",
          "body": "Sedan",
          "img": "../assets/img/download.jpeg"
      },
      {
          "model": "Hyundai",
          "year": 2019,
          "color": "Yellow",
          "body": "Convertible",
          "img": "../assets/img/download.jpeg"
      }
  ];
}