const template = document.getElementById('people-template');
    const peopleTemplate = template.content.querySelector('.people');
    const peopleDiv = document.getElementById('peopleDiv');

    getData().forEach(person => {
        const peopleElem = document.importNode(peopleTemplate, true);
        for (const key in person) {
            if (key === 'img') {
                peopleElem.querySelector('.img').src = person[key];
            } else {
                const element = peopleElem.querySelector('.' + key);
                if (element) {
                    element.textContent = person[key];
                }
            }
        }
        peopleDiv.appendChild(peopleElem);
    });

    function getData() {
        return [
            {
                "name": "Masha",
                "year": 2010,
                "img": "../assets/img/Masha.jpg"
            },
            {
                "name": "Bob",
                "year": 1995,
                "img": "../assets/img/SpongeBob.jpg"
            },
            {
                "name": "Patrik",
                "year": 1997,
                "img": "../assets/img/patrik.jpg"
            },
            {
                "name": "Cheburaska",
                "year": 1983,
                "img": "../assets/img/Cheburaska.jpg"
            },
            {
                "name": "Gena",
                "year": 1969,
                "img": "../assets/img/Gena.jpg"
            }
        ];
    }