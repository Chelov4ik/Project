//нужно зарегаться на сайте EmailJS и создать там сервер и template message а после взять айди и подключить


(function(){
    emailjs.init("YOUR_USER_ID"); 
})();

function sendEmail() {
    var templateParams = {
        to_name: 'Recipient Name',
        from_name: 'Your Name',
        message: 'Текст сообщения'
    };

    emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', templateParams)
        .then(function(response) {
            console.log('SUCCESS!', response.status, response.text);
        }, function(error) {
            console.log('FAILED...', error);
        });
}